# streamlit_app.py
import streamlit as st
import pandas as pd
import yfinance as yf
import matplotlib.pyplot as plt
from datetime import datetime

st.set_page_config(page_title="10-Year Dividend Tracker", layout="wide")

st.title("📊 10-Year Monthly Dividend Tracker (Philippines)")
st.caption("Live prices via Yahoo Finance • Monthly dividend projection • Exportable")

stocks = st.multiselect(
    "Select Stocks",
    ['MBT.PH', 'SCC.PH', 'DMC.PH', 'CREIT.PH', 'RCR.PH', 'MREIT.PH', 'TEL.PH'],
    default=['MBT.PH', 'SCC.PH', 'DMC.PH', 'CREIT.PH', 'RCR.PH', 'MREIT.PH', 'TEL.PH']
)

biweekly_amount = st.number_input("Bi-weekly Investment (₱)", 1000, 50000, 7500, step=500)
start_date = st.date_input("Start Date", datetime(2026, 1, 1))
years = st.slider("Years", 1, 15, 10)

months = pd.date_range(start=start_date, periods=years * 12, freq="M")
df = pd.DataFrame({"Month": months})

for s in stocks:
    df[f"{s}_Shares"] = 0.0
    df[f"{s}_Dividend"] = 0.0

prices, dividends = {}, {}

with st.spinner("Fetching live prices & dividends..."):
    for s in stocks:
        try:
            t = yf.Ticker(s)
            prices[s] = t.info.get("regularMarketPrice", 0)
            annual_div = t.info.get("dividendRate", 0)
            dividends[s] = annual_div / 12 if annual_div else 0
        except:
            prices[s] = 0
            dividends[s] = 0

if stocks:
    allocation = biweekly_amount * 2 / len(stocks)
    for i in range(len(df)):
        for s in stocks:
            prev = df.loc[i-1, f"{s}_Shares"] if i > 0 else 0
            buy = allocation / prices[s] if prices[s] else 0
            df.loc[i, f"{s}_Shares"] = prev + buy
            df.loc[i, f"{s}_Dividend"] = df.loc[i, f"{s}_Shares"] * dividends[s]

div_cols = [f"{s}_Dividend" for s in stocks]
df["Total Monthly Dividend"] = df[div_cols].sum(axis=1)

def milestone(v):
    if v >= 30000: return "🎯 30k"
    if v >= 25000: return "25k"
    if v >= 20000: return "20k"
    if v >= 15000: return "15k"
    if v >= 10000: return "10k"
    return ""

df["Milestone"] = df["Total Monthly Dividend"].apply(milestone)

st.subheader("📅 Monthly Dividend Table")
st.dataframe(df, use_container_width=True)

st.subheader("📈 Dividend Growth")
fig, ax = plt.subplots(figsize=(10,4))
ax.plot(df["Month"], df["Total Monthly Dividend"])
ax.set_ylabel("Monthly Dividend (₱)")
ax.set_xlabel("Month")
ax.grid(True)
st.pyplot(fig)

st.subheader("⬇️ Export")
excel = df.to_excel(index=False, engine="openpyxl")
st.download_button("Download Excel", excel, "dividend_tracker_10yr.xlsx")
